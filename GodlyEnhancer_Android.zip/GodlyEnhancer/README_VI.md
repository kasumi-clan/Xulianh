# Godly Enhancer — Hệ thống AI thích ứng 3 model (báo cáo trung thực)

**Kết luận ngắn:** khung hệ thống thích ứng (phân tích ảnh → chọn model → chạy tuần tự → kiểm tra giữa các giai đoạn → so sánh/xuất) đã được VIẾT.
**Cả 3 model (VOSR 0.5B, NAFNet, CodeFormer) CHƯA chạy suy luận thật trên Android** → hệ thống 3 model **CHƯA hoàn thành**.
Gói này **chưa build, chưa chạy, chưa kiểm thử** (môi trường tạo gói không có Android SDK/Gradle/mạng/GPU). Không có AI giả, không có model thay thế.

## A. Hành vi hiện tại của app (khi bạn bấm "✨ Làm rõ ảnh")
1. "Đang phân tích ảnh": đo nhiễu/độ nét trên 5 vùng ở độ phân giải gốc, dò khuôn mặt cơ bản, đọc RAM trống — **chỉ là ước lượng**.
2. Chọn model theo luật (mục D). Ảnh đã rõ → báo "không cần dùng model AI", giữ nguyên ảnh gốc.
3. Model cần mà không chạy được → hiện **lý do chính xác**, bỏ qua an toàn, giữ ảnh gốc. Hiện tại cả 3 đều ở trạng thái này,
   nên app dừng ở bước 3: bạn sẽ thấy kết quả phân tích + kế hoạch + lý do chưa chạy được.
4. (Khi có model thật) chạy tuần tự NAFNet → VOSR → CodeFormer; mỗi giai đoạn giải phóng engine; kiểm tra kích thước/tỷ lệ/dải động/độ sáng giữa các giai đoạn;
   giai đoạn lỗi hoặc đầu ra bất thường bị loại, không thay bằng model khác.

## B. Xác minh model (nguồn đã tra; "chưa" = chưa xác minh được)
| | VOSR 0.5B One-Step | NAFNet | CodeFormer |
|---|---|---|---|
| Checkpoint chính thức | thư mục `VOSR_0.5B_os/` trong HF `CSWRY/VOSR` (https://huggingface.co/CSWRY/VOSR) | GoPro-width32/64 (khử mờ), SIDD-width32/64 (khử nhiễu), REDS-width64 (khử mờ + JPEG) — https://github.com/megvii-research/NAFNet | `codeformer.pth` ở GitHub release v0.1.0 — https://github.com/sczhou/CodeFormer |
| Tên tệp chính xác | chưa thấy (chỉ thấy tên thư mục; thư mục VOSR2 có `checkpoints/` + `args.json`) | chưa thấy (host Google Drive/Baidu) | `codeformer.pth` |
| Dung lượng tải | chưa đo (thư mục VOSR2 1.4B: 5,58 GB; `sd21_lwdecoder.pth`: 52,1 MB) | chưa đo | chưa đo |
| Giấy phép | VOSR: Apache-2.0; thành phần bên thứ ba theo điều khoản riêng | có tệp LICENSE, **chưa đọc nội dung** | **S-Lab License 1.0** (không phải giấy phép mở chuẩn; trang demo ghi liên quan mục đích phi thương mại) → **phải đọc kỹ LICENSE trước khi phát hành** |
| Kiến trúc | DiT: dim 1024, depth 28, 16 head, patch 2, MLP ×4; VAE SD2.1 với decoder nhẹ; điều kiện DINOv2 | NAFNet (không hàm kích hoạt phi tuyến) | Transformer + codebook: dim 512, codebook 1024, 8 head, 9 lớp |
| Phụ thuộc | PyTorch (Python ≥ 3.8), DINOv2, VAE | PyTorch 1.11, Python 3.9.5, BasicSR | + dò mặt RetinaFace (`detection_Resnet50_Final.pth`) + parsing (`parsing_parsenet.pth`); RealESRGAN_x2plus chỉ cho nền (**không dùng**) |
| Chuyển đổi Android | **chưa thử**; không thấy bản 0.5B cho Android | **chưa thử**; chỉ có PyTorch | **chưa thử**; cần thêm dò/căn chỉnh mặt + ghép lại |
| Suy luận thật trên Android | **không** | **không** | **không** |
| RAM đỉnh | chưa đo | chưa đo | chưa đo |

**Đính chính lời trước:** mình từng nói chưa thấy bản VOSR cho Android. Sau khi tra thêm có bản **VOSR 1.4B QNN** (https://huggingface.co/AllGPTORG/VOSR_1.4B_Mobile)
nhưng chỉ nhắm Snapdragon 8 Gen 3 (NPU Qualcomm), tổng 1,617 GiB, tile 512 — **không áp dụng cho Galaxy A51**. Không có bản 0.5B tương đương.

**CodeFormer là thành phần thứ tư ngầm:** nó cần bộ dò + căn chỉnh khuôn mặt (RetinaFace hoặc tương đương). Phân tích ảnh hiện dùng bộ dò mặt cơ bản của Android
(`android.media.FaceDetector`: chỉ mặt gần chính diện, không có điểm mốc để căn chỉnh) — **không đủ cho CodeFormer**. Chọn bộ dò thật là việc còn lại.

## C. Phân tích ảnh — đã kiểm chứng gì
Công thức đã chạy thử bằng bản **Python tương đương** trên ảnh tổng hợp (chưa phải ảnh chụp thật, chưa phải mã Kotlin):
- Ước lượng nhiễu (Immerkaer): thêm σ=3/10/20 → ước lượng 3,00/9,95/19,71. Đáng tin trên ảnh tổng hợp.
- Phương sai Laplacian bị nhiễu đẩy lên giả (σ=5: 689 so với 194 khi sạch) → app **không đánh giá độ mờ khi nhiễu cao**.
- Bất đẳng hướng: mờ chuyển động ngang 4,1–5,0; dọc 3,0–4,0; ảnh đẳng hướng 1,2–1,3 → ngưỡng 2,0 phân biệt được.
  **Mờ chéo 45° KHÔNG phát hiện được (1,37).** Nhiễu trắng thuần cho 2,03 → có thêm điều kiện "ảnh phải có cấu trúc".
- Mờ KHÔNG rõ hướng (mất nét) → **không dùng NAFNet** (chưa có checkpoint phù hợp đã xác minh) → để VOSR xử lý.
- Mọi ngưỡng quyết định là heuristic, **chưa hiệu chỉnh trên ảnh thật của A51**.

## D. Luật chọn model
- Tối đa **một** thao tác NAFNet (tránh áp dụng model hai lần): nhiễu cao → khử nhiễu (SIDD); mờ có hướng → khử mờ (GoPro).
- VOSR: cạnh dài < 1280 px hoặc thiếu chi tiết/mờ không rõ hướng. Hệ số phóng đại và giới hạn kích thước đầu ra: **chưa quyết, cần thử nghiệm thật**.
- CodeFormer: chỉ khi phát hiện mặt chưa rõ **và** bạn bật công tắc "Cải thiện khuôn mặt" (mặc định tắt).
- Thứ tự: NAFNet → VOSR → CodeFormer. Bước nào không cần thì bỏ qua và ghi lý do.

## E. Tình trạng tính năng
| Tính năng | Đã viết | Đã kiểm thử |
|---|---|---|
| Phân tích ảnh (nhiễu, độ nét, hướng mờ, mặt, RAM) | Có | Công thức: Python tổng hợp. Mã Kotlin: 5 test JVM đã viết, chưa chạy |
| Bộ chọn model + ghi lý do bỏ qua/chặn | Có | 12 test JVM đã viết, **chưa chạy** |
| Pipeline tuần tự + giải phóng sau mỗi giai đoạn + kiểm tra giữa giai đoạn | Có | Chưa |
| Engine VOSR / NAFNet khử nhiễu / NAFNet khử mờ / CodeFormer | **Không (chặn)** | — |
| Mô tả giai đoạn trung thực, không % giả | Có | Chưa |
| Công tắc khuôn mặt (opt-in) | Có | Chưa |
| Chọn ảnh, so sánh Trước/Sau, xuất WebP95/PNG, dọn tạm, theo dõi nhiệt | Có | 7 test dọn tạm đã viết, chưa chạy; còn lại chưa |
| Quản lý OOM | Một phần: bắt OOM từng giai đoạn, ước lượng RAM do engine cung cấp (hiện chưa có) | Chưa |
| Tái sử dụng phiên model khi đủ RAM | **Chưa** (hiện luôn giải phóng sau mỗi giai đoạn — an toàn nhưng chậm hơn) | — |
| Trình tải model | Mã có (`ModelStore.download`) nhưng **chưa nối vào UI**: chưa có nguồn model Android đã xác minh | Chưa |

## F. Tiêu chí chấp nhận (mục 10 của prompt)
Chọn model đúng: viết xong, chưa chạy · Bỏ qua model thừa: viết xong, chưa chạy · **Model chạy suy luận thật: KHÔNG (0/3)** · Tuần tự: viết xong, chưa chạy ·
RAM an toàn: một phần · Ảnh gốc không đổi: thiết kế chỉ đọc + chỉ xóa trong thư mục tạm, chưa chạy test · So sánh/xuất: viết xong, chưa chạy ·
Báo model không hỗ trợ trung thực: có. → **Chưa đạt tiêu chí chấp nhận.**

## G. Build / tự kiểm thử
1. Đẩy toàn bộ lên GitHub nhánh `main` → tab **Actions → Build APK** (chạy test JVM trước, rồi build APK). Nếu đỏ, gửi log.
2. Khi xanh, cài APK debug. Kỳ vọng ở bản này: chọn ảnh → "✨ Làm rõ ảnh" → thấy phân tích + kế hoạch + lý do các model chưa chạy được; ảnh gốc không đổi.

## H. Bước tiếp theo
Với từng model, thử nghiệm chuyển đổi trên máy có GPU (Colab/Kaggle) → ONNX → kiểm tra toán tử ONNX Runtime Mobile hỗ trợ → đo dung lượng và chạy thử một ô ảnh trên CPU điện thoại.
Thứ tự đề xuất theo độ rủi ro thấp → cao: NAFNet (CNN nhỏ) → CodeFormer (cần thêm dò mặt) → VOSR 0.5B (DiT + VAE + DINOv2).
