package com.godly.enhancer.engine

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.security.MessageDigest

/** Nguồn tải model đã xác minh. [sha256] = null nghĩa là nguồn không cung cấp checksum. */
data class ModelSource(val url: String, val sha256: String?, val bytes: Long)

/**
 * Quản lý trọng số model trong vùng lưu trữ riêng của ứng dụng (filesDir/models).
 * Tuyệt đối không bị "Dọn bộ nhớ tạm" đụng tới — chỉ xóa khi người dùng chọn xóa trong Cài đặt.
 */
class ModelStore(private val dir: File) {

    companion object {
        /**
         * Chưa có nguồn tải VOSR 2.0 dạng Android đã xác minh → null.
         * KHÔNG điền URL chưa kiểm chứng vào đây.
         */
        val SOURCE: ModelSource? = null
    }

    fun isInstalled(): Boolean = File(dir, "model.bin").isFile

    fun installedBytes(): Long =
        if (dir.exists()) dir.walkTopDown().filter { it.isFile }.sumOf { it.length() } else 0L

    fun delete(): Boolean = !dir.exists() || (dir.deleteRecursively() && !dir.exists())

    /** Tải có tiếp tục (Range), tiến trình thật, kiểm checksum nếu có; file hỏng bị xóa. */
    suspend fun download(src: ModelSource, onProgress: (Long, Long) -> Unit): Unit =
        withContext(Dispatchers.IO) {
            dir.mkdirs()
            val part = File(dir, "model.bin.part")
            val target = File(dir, "model.bin")
            val existing = if (part.exists()) part.length() else 0L

            val conn = URL(src.url).openConnection() as HttpURLConnection
            conn.connectTimeout = 15_000
            conn.readTimeout = 30_000
            if (existing > 0) conn.setRequestProperty("Range", "bytes=$existing-")
            try {
                val code = conn.responseCode
                val append = code == HttpURLConnection.HTTP_PARTIAL
                if (!append && code != HttpURLConnection.HTTP_OK) {
                    throw IOException("Máy chủ trả về mã $code")
                }
                val start = if (append) existing else 0L
                val total = if (src.bytes > 0) src.bytes else start + conn.contentLengthLong
                conn.inputStream.use { input ->
                    FileOutputStream(part, append).use { out ->
                        val buf = ByteArray(64 * 1024)
                        var done = start
                        while (true) {
                            ensureActive()
                            val n = input.read(buf)
                            if (n < 0) break
                            out.write(buf, 0, n)
                            done += n
                            onProgress(done, total)
                        }
                    }
                }
            } finally {
                conn.disconnect()
            }

            val expected = src.sha256
            if (expected != null && !sha256(part).equals(expected, ignoreCase = true)) {
                part.delete()
                throw IOException("Tệp tải về không khớp checksum (bị hỏng) — đã xóa tệp lỗi.")
            }
            if (!part.renameTo(target)) throw IOException("Không thể hoàn tất cài đặt model.")
            Unit
        }

    private fun sha256(f: File): String {
        val md = MessageDigest.getInstance("SHA-256")
        f.inputStream().use { ins ->
            val b = ByteArray(1 shl 16)
            while (true) {
                val n = ins.read(b)
                if (n < 0) break
                md.update(b, 0, n)
            }
        }
        return md.digest().joinToString("") { "%02x".format(it) }
    }
}
