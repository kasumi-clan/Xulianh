package com.godly.enhancer.analysis

/** Ảnh xám (độ sáng 0..255) dạng mảng phẳng — thuần Kotlin để kiểm thử JVM được. */
class Gray(val w: Int, val h: Int, val v: FloatArray) {
    init {
        require(v.size == w * h) { "Kích thước mảng không khớp w*h" }
    }

    operator fun get(x: Int, y: Int): Float = v[y * w + x]
}

data class LumaStats(val p1: Float, val p99: Float, val mean: Float)
