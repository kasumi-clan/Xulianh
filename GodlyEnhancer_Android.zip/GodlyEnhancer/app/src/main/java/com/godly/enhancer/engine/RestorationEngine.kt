package com.godly.enhancer.engine

import android.content.Context
import android.net.Uri
import java.io.File

/** Các giai đoạn model trong pipeline thích ứng (NAFNet có 2 checkpoint theo từng tác vụ). */
enum class StageType(val label: String, val runningLabel: String) {
    NafnetDenoise("NAFNet khử nhiễu (checkpoint SIDD)", "Đang khử nhiễu"),
    NafnetDeblur("NAFNet khử mờ chuyển động (checkpoint GoPro)", "Đang khử mờ"),
    Vosr("VOSR 0.5B One-Step", "Đang phục hồi chi tiết"),
    CodeFormer("CodeFormer", "Đang cải thiện khuôn mặt"),
}

sealed interface EngineStatus {
    data class Ready(val modelName: String, val backend: String) : EngineStatus
    data object NotInstalled : EngineStatus
    data class Blocked(val reason: String) : EngineStatus
}

class RestoreRequest(
    val context: Context,
    /** Đầu vào giai đoạn: ảnh gốc của người dùng (CHỈ ĐỌC) hoặc đầu ra giai đoạn trước (file://). */
    val source: Uri,
    /** Thư mục tạm của phiên (được dọn sau khi xong/hủy/lỗi). */
    val workDir: File,
    /** Engine phải ghi ảnh kết quả PNG thật vào đây. */
    val output: File,
    /** Chỉ gọi khi có tiến độ đo được thật (0f..1f). Không gọi = hiển thị chờ không xác định. */
    val onProgress: (Float) -> Unit,
    /** Engine phải kiểm tra định kỳ và dừng an toàn khi true. */
    val isThermalCritical: () -> Boolean,
)

interface RestorationEngine {
    val status: EngineStatus

    /** Ước lượng RAM cần (byte) cho ảnh w×h, hoặc null nếu chưa biết (không bịa số). */
    fun estimateRamBytes(width: Int, height: Int): Long?

    /**
     * Chạy suy luận thật. Ném exception nếu thất bại; phải tôn trọng hủy coroutine.
     * Quy ước: NAFNet và CodeFormer giữ nguyên kích thước; VOSR giữ tỷ lệ khung hình.
     * Phải áp dụng xoay EXIF của đầu vào giống bản xem trước.
     */
    suspend fun restore(request: RestoreRequest)

    /** Giải phóng phiên runtime/tensor. Pipeline gọi sau MỖI giai đoạn (chạy tuần tự). */
    fun release()
}
