package com.godly.enhancer.device

import android.content.Context
import android.os.PowerManager
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

/** Theo dõi trạng thái nhiệt qua Android Thermal API (minSdk 29). Không đo/đoán nhiệt độ. */
class ThermalMonitor(context: Context) {
    private val pm = context.getSystemService(PowerManager::class.java)
    private val _status = MutableStateFlow(PowerManager.THERMAL_STATUS_NONE)
    val status: StateFlow<Int> = _status

    private val listener = PowerManager.OnThermalStatusChangedListener { _status.value = it }

    fun start() {
        _status.value = pm.currentThermalStatus
        pm.addThermalStatusListener(listener)
    }

    fun stop() {
        pm.removeThermalStatusListener(listener)
    }

    fun isCritical(): Boolean = _status.value >= PowerManager.THERMAL_STATUS_SEVERE
}
