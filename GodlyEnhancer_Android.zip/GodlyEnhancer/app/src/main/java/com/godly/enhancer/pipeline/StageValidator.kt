package com.godly.enhancer.pipeline

import android.content.Context
import android.net.Uri
import com.godly.enhancer.analysis.ImageMetrics
import com.godly.enhancer.engine.StageType
import com.godly.enhancer.media.ImageIO
import java.io.File
import kotlin.math.abs

data class Validation(val ok: Boolean, val reason: String?, val dims: Pair<Int, Int>?)

/** Kiểm tra giữa các giai đoạn: tệp hợp lệ, kích thước/tỷ lệ, dải động, độ sáng không lệch bất thường. */
object StageValidator {
    private const val FLAT_RANGE = 10f
    private const val MIN_INPUT_RANGE = 30f
    private const val MEAN_SHIFT_MAX = 40f
    private const val ASPECT_TOLERANCE = 0.01

    private fun bad(reason: String) = Validation(false, reason, null)

    fun validate(context: Context, stage: StageType, inDims: Pair<Int, Int>, inUri: Uri, out: File): Validation {
        if (!out.isFile || out.length() == 0L) return bad("không tạo ra tệp kết quả")
        val b = ImageIO.fileBounds(out) ?: return bad("tệp kết quả không giải mã được")
        val dims = b.outWidth to b.outHeight

        when (stage) {
            StageType.Vosr -> {
                val a0 = inDims.first.toDouble() / inDims.second
                val a1 = dims.first.toDouble() / dims.second
                if (abs(a1 - a0) / a0 > ASPECT_TOLERANCE) {
                    return bad("tỷ lệ khung hình bị đổi (${inDims.first}×${inDims.second} → ${dims.first}×${dims.second})")
                }
                if (dims.first < inDims.first || dims.second < inDims.second) return bad("ảnh bị thu nhỏ")
            }
            else -> if (dims != inDims) {
                return bad("kích thước bị đổi (${inDims.first}×${inDims.second} → ${dims.first}×${dims.second}); giai đoạn này phải giữ nguyên kích thước")
            }
        }

        val after = ImageIO.decodePreviewFile(out, 256) ?: return bad("không giải mã được kết quả để kiểm tra dải động")
        val sa = ImageMetrics.lumaStats(ImageIO.toGray(after))
        val before = ImageIO.decodePreview(context.contentResolver, inUri, 256)
        if (before != null) {
            val sb = ImageMetrics.lumaStats(ImageIO.toGray(before))
            if (sb.p99 - sb.p1 >= MIN_INPUT_RANGE && sa.p99 - sa.p1 < FLAT_RANGE) {
                return bad("đầu ra gần như phẳng (dải động ${sa.p99 - sa.p1}) — nghi lỗi")
            }
            if (abs(sa.mean - sb.mean) > MEAN_SHIFT_MAX) {
                return bad("độ sáng trung bình lệch bất thường (${sb.mean.toInt()} → ${sa.mean.toInt()})")
            }
        }
        return Validation(true, null, dims)
    }
}
