package com.godly.enhancer.storage

import java.io.File
import java.io.IOException
import kotlin.random.Random

/**
 * Quản lý thư mục tạm của phiên xử lý. Chỉ xóa tệp NẰM TRONG [root] (kiểm tra bằng đường dẫn chuẩn hóa),
 * nên không bao giờ đụng tới ảnh gốc, ảnh đã xuất hay trọng số model.
 */
class SessionStore(private val root: File) {
    private var current: File? = null

    init {
        root.mkdirs()
    }

    @Synchronized
    fun begin(): File {
        clearCurrent()
        val dir = File(root, "s_${System.currentTimeMillis()}_${Random.nextInt(10_000)}")
        check(dir.mkdirs()) { "Không tạo được thư mục phiên tạm." }
        current = dir
        return dir
    }

    @Synchronized
    fun currentDir(): File? = current

    @Synchronized
    fun clearCurrent(): Boolean {
        val dir = current ?: return true
        val ok = delete(dir)
        if (ok) current = null
        return ok
    }

    /** Dọn các mục tạm. [keepCurrent] = true khi phiên hiện tại đang được màn hình/tác vụ sử dụng. */
    @Synchronized
    fun cleanTemp(keepCurrent: Boolean): Int {
        var removed = 0
        root.listFiles()?.forEach { f ->
            if (keepCurrent && f == current) return@forEach
            if (delete(f)) removed++
        }
        val c = current
        if (c != null && !c.exists()) current = null
        return removed
    }

    fun delete(target: File): Boolean {
        if (!isInsideRoot(target)) return false
        if (!target.exists()) return true
        return target.deleteRecursively() && !target.exists()
    }

    fun isInsideRoot(f: File): Boolean = try {
        f.canonicalPath.startsWith(root.canonicalPath + File.separator)
    } catch (e: IOException) {
        false
    }

    fun totalBytes(): Long = sizeOf(root)

    @Synchronized
    fun currentBytes(): Long = current?.let { sizeOf(it) } ?: 0L

    private fun sizeOf(f: File): Long =
        if (f.exists()) f.walkTopDown().filter { it.isFile }.sumOf { it.length() } else 0L
}
