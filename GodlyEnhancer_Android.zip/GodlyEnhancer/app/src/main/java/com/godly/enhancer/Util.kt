package com.godly.enhancer

import android.os.PowerManager
import java.util.Locale

fun formatBytes(b: Long): String = when {
    b < 1024L -> "$b B"
    b < 1024L * 1024L -> String.format(Locale.US, "%.1f KB", b / 1024.0)
    b < 1024L * 1024L * 1024L -> String.format(Locale.US, "%.1f MB", b / 1048576.0)
    else -> String.format(Locale.US, "%.2f GB", b / 1073741824.0)
}

fun formatSeconds(ms: Long): String = String.format(Locale.US, "%.1f giây", ms / 1000.0)

/** Trạng thái nhiệt lấy từ Android Thermal API (không phải số đo nhiệt độ). */
fun thermalLabel(status: Int): String? = when (status) {
    PowerManager.THERMAL_STATUS_MODERATE -> "Máy đang khá nóng."
    PowerManager.THERMAL_STATUS_SEVERE -> "Máy đang rất nóng — hãy để máy nguội rồi thử lại."
    PowerManager.THERMAL_STATUS_CRITICAL,
    PowerManager.THERMAL_STATUS_EMERGENCY,
    PowerManager.THERMAL_STATUS_SHUTDOWN -> "Máy quá nóng — việc xử lý bị chặn."
    else -> null
}
