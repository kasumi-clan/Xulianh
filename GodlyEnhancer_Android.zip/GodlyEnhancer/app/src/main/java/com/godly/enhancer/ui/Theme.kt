package com.godly.enhancer.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val GodlyBlue = Color(0xFF1E6FEB)
val GodlyBlueSoft = Color(0xFFEAF2FF)
val GodlyText = Color(0xFF0F1B2D)
val GodlyMuted = Color(0xFF4A5B73)

private val scheme = lightColorScheme(
    primary = GodlyBlue,
    onPrimary = Color.White,
    background = Color.White,
    surface = Color.White,
    onSurface = GodlyText,
    surfaceVariant = GodlyBlueSoft,
)

@Composable
fun GodlyTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = scheme, content = content)
}
