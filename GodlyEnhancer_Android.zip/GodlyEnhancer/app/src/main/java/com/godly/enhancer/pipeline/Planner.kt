package com.godly.enhancer.pipeline

import com.godly.enhancer.analysis.AnalysisReport
import com.godly.enhancer.analysis.Thresholds
import com.godly.enhancer.engine.EngineStatus
import com.godly.enhancer.engine.StageType
import com.godly.enhancer.formatBytes
import java.util.Locale
import kotlin.math.max

data class StageAvailability(val status: EngineStatus, val estimateRamBytes: Long?)
data class PlannedStep(val stage: StageType, val reason: String)
data class Blocker(val stage: StageType, val reason: String)

data class RestorePlan(
    /** Các bước CẦN thiết, theo thứ tự chạy: NAFNet → VOSR → CodeFormer. */
    val steps: List<PlannedStep>,
    /** Trong đó, bước chạy được ngay. */
    val runnable: List<PlannedStep>,
    /** Bước cần nhưng không chạy được, kèm lý do chính xác. */
    val blocked: List<Blocker>,
    /** Giải thích các bước bị bỏ qua và hạn chế của số đo. */
    val notes: List<String>,
    /** Có khuôn mặt kém nhưng người dùng chưa bật CodeFormer. */
    val faceSuggested: Boolean,
)

/**
 * Chọn model theo số đo (ước lượng). Quy tắc:
 *  - Tối đa MỘT thao tác NAFNet (tránh áp dụng cùng model hai lần): nhiễu cao → khử nhiễu; mờ có hướng → khử mờ.
 *  - Nhiễu cao làm số đo độ nét sai → không đánh giá mờ khi nhiễu cao.
 *  - Mờ KHÔNG rõ hướng (mất nét…) → không dùng NAFNet (chưa có checkpoint phù hợp đã xác minh), để VOSR lo.
 *  - VOSR khi độ phân giải thấp hoặc thiếu chi tiết. CodeFormer chỉ khi người dùng bật.
 */
object Planner {

    fun plan(r: AnalysisReport, avail: Map<StageType, StageAvailability>, faceOptIn: Boolean): RestorePlan {
        val wanted = mutableListOf<PlannedStep>()
        val notes = mutableListOf<String>()
        val noise = r.noiseSigma
        val sharp = r.sharpness

        if (noise == null || sharp == null) {
            notes += "Không đo được nhiễu/độ nét từ vùng ảnh gốc — các bước dựa trên số đo này bị bỏ qua."
        }
        val noisy = noise != null && noise >= Thresholds.NOISE_HIGH
        val blurry = sharp != null && noise != null && !noisy && sharp < Thresholds.SHARPNESS_LOW
        val motion = blurry && sharp != null && sharp >= Thresholds.SHARPNESS_MIN_STRUCTURE &&
            (r.anisotropy ?: 0.0) >= Thresholds.MOTION_ANISOTROPY
        val lowRes = max(r.width, r.height) < Thresholds.LOWRES_MAX_SIDE
        val detailMissing = blurry && !motion

        // 1) NAFNet — tối đa một thao tác
        if (noisy) {
            wanted += PlannedStep(StageType.NafnetDenoise, "nhiễu ước lượng σ≈${f1(noise)} ≥ ${Thresholds.NOISE_HIGH}")
            notes += "Nhiễu cao nên độ mờ không được đánh giá; chỉ chạy một thao tác NAFNet để tránh áp dụng model hai lần."
        } else if (motion) {
            wanted += PlannedStep(StageType.NafnetDeblur, "mờ có hướng (bất đẳng hướng ≈${f1(r.anisotropy)})")
        } else {
            if (noise != null) notes += "Bỏ qua khử nhiễu: σ≈${f1(noise)} < ${Thresholds.NOISE_HIGH}."
            if (blurry) {
                notes += "Mờ nhưng không rõ hướng (có thể mất nét): chưa có checkpoint NAFNet phù hợp đã xác minh, không dùng NAFNet khử mờ."
            } else if (sharp != null) {
                notes += "Bỏ qua khử mờ: độ nét ước lượng ${f1(sharp)} ≥ ${Thresholds.SHARPNESS_LOW}."
            }
        }

        // 2) VOSR
        if (lowRes) {
            wanted += PlannedStep(StageType.Vosr, "độ phân giải thấp (${r.width}×${r.height}, cạnh dài < ${Thresholds.LOWRES_MAX_SIDE}px)")
        } else if (detailMissing) {
            wanted += PlannedStep(StageType.Vosr, "thiếu chi tiết / mờ không rõ hướng")
        } else {
            notes += "Bỏ qua VOSR: đủ độ phân giải và không thấy thiếu chi tiết."
        }

        // 3) CodeFormer (tùy chọn)
        val degraded = r.faces.count { it.degraded }
        var faceSuggested = false
        if (degraded > 0) {
            if (faceOptIn) {
                wanted += PlannedStep(StageType.CodeFormer, "$degraded khuôn mặt chưa rõ")
            } else {
                faceSuggested = true
                notes += "Phát hiện $degraded khuôn mặt chưa rõ — bật \"Cải thiện khuôn mặt\" nếu muốn dùng CodeFormer."
            }
        } else if (r.faces.isNotEmpty()) {
            notes += "Bỏ qua CodeFormer: khuôn mặt đủ rõ."
        }

        if (r.lowMemory) notes += "Hệ thống báo thiếu RAM — nên đóng bớt ứng dụng khác."

        // Khả dụng + RAM
        val runnable = mutableListOf<PlannedStep>()
        val blocked = mutableListOf<Blocker>()
        for (step in wanted) {
            val a = avail[step.stage]
            val st = a?.status
            val need = a?.estimateRamBytes
            when {
                a == null -> blocked += Blocker(step.stage, "không có thông tin engine")
                st is EngineStatus.Blocked -> blocked += Blocker(step.stage, st.reason)
                st is EngineStatus.NotInstalled -> blocked += Blocker(step.stage, "model chưa được cài")
                need != null && need > r.availMemBytes ->
                    blocked += Blocker(step.stage, "RAM trống ${formatBytes(r.availMemBytes)} không đủ (cần khoảng ${formatBytes(need)})")
                else -> runnable += step
            }
        }
        return RestorePlan(wanted, runnable, blocked, notes, faceSuggested)
    }

    private fun f1(x: Double?): String = if (x == null) "?" else String.format(Locale.US, "%.1f", x)
}
