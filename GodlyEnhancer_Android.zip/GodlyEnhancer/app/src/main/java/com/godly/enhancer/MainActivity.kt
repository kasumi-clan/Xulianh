package com.godly.enhancer

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.godly.enhancer.ui.CompareScreen
import com.godly.enhancer.ui.GodlyTheme
import com.godly.enhancer.ui.HomeScreen
import com.godly.enhancer.ui.ResultScreen
import com.godly.enhancer.ui.SettingsScreen

class MainActivity : ComponentActivity() {
    private val vm: EnhancerViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent { GodlyTheme { App(vm) } }
    }
}

@Composable
private fun App(vm: EnhancerViewModel) {
    val s by vm.ui.collectAsStateWithLifecycle()
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { vm.onPicked(it) }

    when (s.screen) {
        Screen.Home -> HomeScreen(
            s = s,
            onPick = { picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) },
            onRestore = vm::restore,
            onCancel = vm::cancel,
            onSettings = vm::openSettings,
            onFaceOptIn = vm::setFaceOptIn,
        )
        Screen.Result -> ResultScreen(
            s = s,
            onCompare = vm::openCompare,
            onSave = vm::save,
            onNewPhoto = vm::newPhoto,
            onLeave = vm::leaveResult,
        )
        Screen.Compare -> {
            val before = s.sourcePreview
            val after = s.resultPreview
            if (before != null && after != null) {
                CompareScreen(before = before, after = after, onBack = vm::closeCompare)
            } else {
                BackHandler { vm.closeCompare() }
            }
        }
        Screen.Settings -> SettingsScreen(
            s = s,
            onBack = vm::closeSettings,
            onCleanTemp = vm::cleanTemp,
            onDeleteModels = vm::deleteModels,
        )
    }
}
