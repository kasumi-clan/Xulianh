package com.godly.enhancer.analysis

import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

/**
 * Các số đo ƯỚC LƯỢNG (không tuyệt đối chính xác). Công thức đã được kiểm chứng bằng bản Python tương đương
 * trên ảnh tổng hợp; chưa kiểm chứng trên ảnh chụp thật.
 */
object ImageMetrics {

    /** Immerkaer (1996): độ lệch chuẩn nhiễu cộng kiểu Gaussian, thang 0..255. */
    fun noiseSigma(g: Gray): Double {
        if (g.w < 3 || g.h < 3) return 0.0
        var sum = 0.0
        for (y in 1 until g.h - 1) {
            for (x in 1 until g.w - 1) {
                val c = g[x - 1, y - 1] - 2f * g[x, y - 1] + g[x + 1, y - 1] -
                    2f * g[x - 1, y] + 4f * g[x, y] - 2f * g[x + 1, y] +
                    g[x - 1, y + 1] - 2f * g[x, y + 1] + g[x + 1, y + 1]
                sum += abs(c.toDouble())
            }
        }
        return sqrt(Math.PI / 2.0) * sum / (6.0 * (g.w - 2) * (g.h - 2))
    }

    /** Phương sai của Laplacian 3×3 — càng thấp càng mờ. Nhiễu làm số này tăng giả. */
    fun laplacianVariance(g: Gray): Double {
        if (g.w < 3 || g.h < 3) return 0.0
        var n = 0L
        var s = 0.0
        var s2 = 0.0
        for (y in 1 until g.h - 1) {
            for (x in 1 until g.w - 1) {
                val l = (g[x, y - 1] + g[x, y + 1] + g[x - 1, y] + g[x + 1, y] - 4f * g[x, y]).toDouble()
                n++
                s += l
                s2 += l * l
            }
        }
        val mean = s / n
        return s2 / n - mean * mean
    }

    /**
     * Tỷ số năng lượng gradient lớn nhất / nhỏ nhất giữa 4 hướng (0°, 90°, 45°, 135°).
     * ≈1 với ảnh đẳng hướng; lớn khi có mờ theo một hướng (ví dụ mờ chuyển động).
     */
    fun anisotropy(g: Gray): Double {
        if (g.w < 3 || g.h < 3) return 1.0
        var e0 = 0.0
        var e90 = 0.0
        var e45 = 0.0
        var e135 = 0.0
        val inv = 1.0 / sqrt(2.0)
        for (y in 1 until g.h - 1) {
            for (x in 1 until g.w - 1) {
                val gx = (g[x + 1, y] - g[x - 1, y]).toDouble()
                val gy = (g[x, y + 1] - g[x, y - 1]).toDouble()
                val d1 = (g[x + 1, y + 1] - g[x - 1, y - 1]) * inv
                val d2 = (g[x + 1, y - 1] - g[x - 1, y + 1]) * inv
                e0 += gx * gx
                e90 += gy * gy
                e45 += d1 * d1
                e135 += d2 * d2
            }
        }
        val mx = max(max(e0, e90), max(e45, e135))
        val mn = min(min(e0, e90), min(e45, e135))
        return mx / max(mn, 1e-9)
    }

    /** Thu nhỏ 2×2 bằng trung bình (giảm nhiễu trước khi đo độ nét). */
    fun downsample2(g: Gray): Gray {
        val w = g.w / 2
        val h = g.h / 2
        val out = FloatArray(w * h)
        for (y in 0 until h) {
            for (x in 0 until w) {
                out[y * w + x] = (g[2 * x, 2 * y] + g[2 * x + 1, 2 * y] + g[2 * x, 2 * y + 1] + g[2 * x + 1, 2 * y + 1]) / 4f
            }
        }
        return Gray(w, h, out)
    }

    /** Phân vị 1% / 99% và trung bình của độ sáng (dải động). */
    fun lumaStats(g: Gray): LumaStats {
        val hist = IntArray(256)
        var sum = 0.0
        for (f in g.v) {
            val i = f.toInt().coerceIn(0, 255)
            hist[i]++
            sum += f
        }
        val total = g.v.size
        fun percentile(p: Double): Float {
            val target = (total * p).toLong()
            var acc = 0L
            for (i in 0..255) {
                acc += hist[i]
                if (acc >= target) return i.toFloat()
            }
            return 255f
        }
        return LumaStats(percentile(0.01), percentile(0.99), (sum / max(total, 1)).toFloat())
    }
}
