package com.godly.enhancer.media

import android.content.ContentResolver
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.ImageDecoder
import android.media.ExifInterface
import android.net.Uri
import com.godly.enhancer.ImageInfo
import com.godly.enhancer.analysis.Gray
import java.io.File
import kotlin.math.max

object ImageIO {

    /** Đọc kích thước (đã tính xoay EXIF) mà không giải mã toàn bộ ảnh. */
    fun readInfo(cr: ContentResolver, uri: Uri): ImageInfo? {
        val opts = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        try {
            cr.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) }
        } catch (e: Exception) {
            return null
        }
        if (opts.outWidth <= 0 || opts.outHeight <= 0) return null

        val exifOrientation: Int? = try {
            cr.openInputStream(uri)?.use {
                ExifInterface(it).getAttributeInt(
                    ExifInterface.TAG_ORIENTATION,
                    ExifInterface.ORIENTATION_NORMAL,
                )
            }
        } catch (e: Exception) {
            null
        }
        val swap = (exifOrientation ?: ExifInterface.ORIENTATION_NORMAL) in 5..8
        return ImageInfo(
            width = if (swap) opts.outHeight else opts.outWidth,
            height = if (swap) opts.outWidth else opts.outHeight,
            mime = opts.outMimeType,
        )
    }

    /** Bản xem trước thu nhỏ (chỉ để hiển thị). Ảnh gốc không bị đổi. ImageDecoder tự áp dụng xoay EXIF. */
    fun decodePreview(cr: ContentResolver, uri: Uri, maxSide: Int): Bitmap? =
        decode(ImageDecoder.createSource(cr, uri), maxSide)

    fun decodePreviewFile(file: File, maxSide: Int): Bitmap? =
        decode(ImageDecoder.createSource(file), maxSide)

    private fun decode(src: ImageDecoder.Source, maxSide: Int): Bitmap? = try {
        ImageDecoder.decodeBitmap(src) { decoder, info, _ ->
            val longest = max(info.size.width, info.size.height)
            decoder.setTargetSampleSize(max(1, longest / maxSide))
            decoder.allocator = ImageDecoder.ALLOCATOR_SOFTWARE
        }
    } catch (e: Exception) {
        null
    } catch (e: OutOfMemoryError) {
        null
    }

    fun fileBounds(file: File): BitmapFactory.Options? {
        val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(file.path, o)
        return if (o.outWidth > 0 && o.outHeight > 0) o else null
    }

    fun fileDims(file: File): Pair<Int, Int>? = fileBounds(file)?.let { it.outWidth to it.outHeight }

    /** Độ sáng 0..255 (Rec.601). Bitmap phải là bitmap phần mềm (không phải HARDWARE). */
    fun toGray(bmp: Bitmap): Gray {
        val w = bmp.width
        val h = bmp.height
        val px = IntArray(w * h)
        bmp.getPixels(px, 0, w, 0, 0, w, h)
        val v = FloatArray(w * h)
        for (i in px.indices) {
            val c = px[i]
            v[i] = 0.299f * ((c shr 16) and 0xFF) + 0.587f * ((c shr 8) and 0xFF) + 0.114f * (c and 0xFF)
        }
        return Gray(w, h, v)
    }
}
