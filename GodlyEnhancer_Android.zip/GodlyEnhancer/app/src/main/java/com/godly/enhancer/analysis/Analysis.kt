package com.godly.enhancer.analysis

/**
 * Ngưỡng QUYẾT ĐỊNH là heuristic, chưa được hiệu chỉnh trên ảnh thật của Galaxy A51.
 * Cần chỉnh lại sau khi có dữ liệu thử nghiệm thực tế.
 */
object Thresholds {
    const val NOISE_HIGH = 8.0                  // σ nhiễu (thang 0..255) từ đó coi là nhiễu cao
    const val SHARPNESS_LOW = 100.0             // phương sai Laplacian (crop nét nhất, đã thu nhỏ 2×2)
    const val MOTION_ANISOTROPY = 2.0           // bất đẳng hướng từ đó coi là mờ có hướng
    const val SHARPNESS_MIN_STRUCTURE = 5.0     // dưới mức này ảnh gần như phẳng: bất đẳng hướng không đáng tin
    const val LOWRES_MAX_SIDE = 1280            // cạnh dài (px) dưới mức này coi là độ phân giải thấp
    const val FACE_SMALL_EYE_DIST_PX = 48f      // khoảng cách hai mắt (px gốc) dưới mức này coi là mặt nhỏ/kém
    const val FACE_SHARPNESS_LOW = 60.0         // độ nét vùng mặt thấp
}

data class FaceInfo(
    val eyeDistNativePx: Float,
    val regionSharpness: Double?,
    val degraded: Boolean,
)

data class AnalysisReport(
    val width: Int,
    val height: Int,
    /** null = không đo được. */
    val noiseSigma: Double?,
    val sharpness: Double?,
    val anisotropy: Double?,
    val cropsUsed: Int,
    val faces: List<FaceInfo>,
    val faceNote: String,
    val availMemBytes: Long,
    val lowMemory: Boolean,
)
