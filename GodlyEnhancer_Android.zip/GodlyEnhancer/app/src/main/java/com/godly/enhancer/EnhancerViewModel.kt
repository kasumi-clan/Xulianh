package com.godly.enhancer

import android.app.Application
import android.net.Uri
import android.os.SystemClock
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.godly.enhancer.analysis.ImageAnalyzer
import com.godly.enhancer.device.ThermalMonitor
import com.godly.enhancer.engine.EngineRegistry
import com.godly.enhancer.media.ExportFormat
import com.godly.enhancer.media.ImageExporter
import com.godly.enhancer.media.ImageIO
import com.godly.enhancer.pipeline.Planner
import com.godly.enhancer.pipeline.RestorePipeline
import com.godly.enhancer.storage.SessionStore
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

class EnhancerViewModel(app: Application) : AndroidViewModel(app) {
    private val ctx = app.applicationContext
    private val sessions = SessionStore(File(ctx.cacheDir, "godly_session"))
    private val registry = EngineRegistry(File(ctx.filesDir, "models"))
    private val analyzer = ImageAnalyzer(ctx)
    private val pipeline = RestorePipeline(registry)
    private val thermal = ThermalMonitor(ctx)

    /** Mỗi lần chỉ một tác vụ nặng (phân tích + pipeline). Chặn suy luận trùng lặp. */
    private var job: Job? = null

    private val _ui = MutableStateFlow(UiState(models = registry.statuses()))
    val ui: StateFlow<UiState> = _ui.asStateFlow()

    init {
        // Tiến trình mới không có phiên nào đang dùng → dọn tệp tạm còn sót từ lần chạy trước.
        sessions.cleanTemp(keepCurrent = false)
        thermal.start()
        viewModelScope.launch {
            thermal.status.collect { st -> _ui.update { it.copy(thermal = st) } }
        }
        refreshStorage()
    }

    override fun onCleared() {
        thermal.stop()
        job?.cancel()
        registry.releaseAll()
        sessions.clearCurrent()
    }

    // ---------- chọn ảnh ----------
    fun onPicked(uri: Uri?) {
        if (uri == null || _ui.value.processing) return
        viewModelScope.launch {
            val cr = ctx.contentResolver
            val (info, preview) = withContext(Dispatchers.IO) {
                ImageIO.readInfo(cr, uri) to ImageIO.decodePreview(cr, uri, PREVIEW_MAX)
            }
            if (info == null || preview == null) {
                _ui.update { it.copy(message = "Không đọc được ảnh này. Định dạng có thể chưa được hỗ trợ.") }
                return@launch
            }
            sessions.clearCurrent()
            _ui.update {
                it.copy(
                    sourceUri = uri, sourceInfo = info, sourcePreview = preview,
                    analysis = null, plan = null, summary = null,
                    result = null, resultPreview = null, saved = false, message = null,
                )
            }
            refreshStorage()
        }
    }

    fun setFaceOptIn(on: Boolean) = _ui.update { it.copy(faceOptIn = on) }

    // ---------- "✨ Làm rõ ảnh": phân tích → chọn model → chạy tuần tự ----------
    fun restore() {
        val s = _ui.value
        val uri = s.sourceUri ?: return
        val info = s.sourceInfo ?: return
        val preview = s.sourcePreview ?: return
        if (s.processing || job?.isActive == true) return
        if (thermal.isCritical()) {
            _ui.update { it.copy(message = "Máy đang quá nóng. Hãy để máy nguội rồi thử lại. Ảnh gốc vẫn được giữ nguyên.") }
            return
        }

        _ui.update {
            it.copy(
                processing = true, stageLabel = "Đang phân tích ảnh", progress = null, message = null,
                analysis = null, plan = null, summary = null,
            )
        }
        job = viewModelScope.launch {
            try {
                val report = withContext(Dispatchers.Default) { analyzer.analyze(uri, info, preview) }
                val plan = Planner.plan(report, registry.availability(info.width, info.height), _ui.value.faceOptIn)
                _ui.update { it.copy(analysis = report, plan = plan) }

                if (plan.steps.isEmpty()) {
                    _ui.update { it.copy(message = "Ảnh đã khá rõ — không cần dùng model AI. Ảnh gốc được giữ nguyên.") }
                    return@launch
                }
                if (plan.runnable.isEmpty()) {
                    _ui.update {
                        it.copy(message = "Chưa thể xử lý: các model cần thiết đang không khả dụng (lý do chính xác ở bên dưới). Ảnh gốc được giữ nguyên.")
                    }
                    return@launch
                }

                val dir = sessions.begin()
                val out = File(dir, "result.png")
                val t0 = SystemClock.elapsedRealtime()
                val res = withContext(Dispatchers.Default) {
                    pipeline.run(
                        context = ctx, source = uri, sourceInfo = info, workDir = dir, finalOutput = out,
                        steps = plan.runnable,
                        onStage = { label -> _ui.update { it.copy(stageLabel = label, progress = null) } },
                        onProgress = { p -> _ui.update { it.copy(progress = p) } },
                        isThermalCritical = { thermal.isCritical() },
                    )
                }
                val skipped = plan.blocked.map { "${it.stage.label}: ${it.reason}" } + res.skipped
                val file = res.output
                if (file == null) {
                    sessions.clearCurrent()
                    _ui.update {
                        it.copy(
                            summary = RunSummary(res.executed, skipped),
                            message = "Không giai đoạn nào tạo được kết quả hợp lệ. Ảnh gốc được giữ nguyên.",
                        )
                    }
                    return@launch
                }
                val millis = SystemClock.elapsedRealtime() - t0
                val dims = ImageIO.fileDims(file) ?: throw IllegalStateException("Kết quả không hợp lệ.")
                val prev = withContext(Dispatchers.IO) { ImageIO.decodePreviewFile(file, PREVIEW_MAX) }
                    ?: throw IllegalStateException("Không giải mã được ảnh kết quả.")
                _ui.update {
                    it.copy(
                        screen = Screen.Result, saved = false,
                        result = ResultInfo(file, dims.first, dims.second, millis), resultPreview = prev,
                        summary = RunSummary(res.executed, skipped),
                    )
                }
            } catch (e: CancellationException) {
                sessions.clearCurrent()
                _ui.update { it.copy(message = "Đã hủy. Ảnh gốc được giữ nguyên.") }
                throw e
            } catch (t: Throwable) {
                sessions.clearCurrent()
                _ui.update { it.copy(message = friendly(t)) }
            } finally {
                registry.releaseAll()
                _ui.update { it.copy(processing = false, stageLabel = null, progress = null) }
                refreshStorage()
            }
        }
    }

    fun cancel() {
        job?.cancel()
    }

    // ---------- điều hướng / vòng đời kết quả ----------
    fun openCompare() = _ui.update { if (it.result != null) it.copy(screen = Screen.Compare) else it }
    fun closeCompare() = _ui.update { it.copy(screen = Screen.Result) }
    fun openSettings() {
        refreshStorage()
        _ui.update { it.copy(screen = Screen.Settings, message = null, models = registry.statuses()) }
    }
    fun closeSettings() = _ui.update { it.copy(screen = Screen.Home, message = null) }

    /** "Xử lý ảnh khác": xóa kết quả tạm thật trên đĩa + giải phóng ảnh trong RAM, bắt đầu phiên mới. */
    fun newPhoto() {
        if (_ui.value.saving) return
        sessions.clearCurrent()
        _ui.update {
            it.copy(
                screen = Screen.Home, sourceUri = null, sourceInfo = null, sourcePreview = null,
                analysis = null, plan = null, summary = null,
                result = null, resultPreview = null, saved = false, message = null,
            )
        }
        refreshStorage()
    }

    /** Rời màn hình kết quả (đã xác nhận nếu chưa lưu): xóa kết quả tạm, giữ ảnh gốc đang chọn. */
    fun leaveResult() {
        if (_ui.value.saving) return
        sessions.clearCurrent()
        _ui.update { it.copy(screen = Screen.Home, result = null, resultPreview = null, saved = false) }
        refreshStorage()
    }

    // ---------- xuất ảnh ----------
    fun save(format: ExportFormat) {
        val r = _ui.value.result ?: return
        if (_ui.value.saving) return
        _ui.update { it.copy(saving = true, message = null) }
        viewModelScope.launch {
            val res = withContext(Dispatchers.IO) { runCatching { ImageExporter.export(ctx, r.file, format) } }
            res.onSuccess { e ->
                _ui.update {
                    it.copy(
                        saving = false, saved = true,
                        message = "Đã lưu ảnh thành công\n${e.name}\n${e.format.label} · ${formatBytes(e.bytes)} · ${e.width}×${e.height} px",
                    )
                }
            }.onFailure { t ->
                _ui.update { it.copy(saving = false, message = t.message ?: "Lưu ảnh thất bại.") }
            }
            refreshStorage()
        }
    }

    // ---------- lưu trữ ----------
    fun cleanTemp() {
        val s = _ui.value
        val inUse = s.processing || s.saving || s.result != null
        val n = sessions.cleanTemp(keepCurrent = inUse)
        _ui.update { it.copy(message = if (n > 0) "Đã dọn $n mục tạm." else "Không có tệp tạm nào cần dọn.") }
        refreshStorage()
    }

    fun deleteModels() {
        if (_ui.value.processing || job?.isActive == true) return
        val ok = registry.deleteAllModels()
        _ui.update { it.copy(models = registry.statuses(), message = if (ok) "Đã xóa model đã tải." else "Không xóa được model.") }
        refreshStorage()
    }

    private fun refreshStorage() {
        viewModelScope.launch(Dispatchers.IO) {
            val st = StorageStats(
                modelBytes = registry.installedBytes(),
                tempBytes = sessions.totalBytes(),
                sessionBytes = sessions.currentBytes(),
            )
            _ui.update { it.copy(storage = st) }
        }
    }

    private fun friendly(t: Throwable): String = when (t) {
        is OutOfMemoryError -> "Không đủ RAM để xử lý ảnh này. Ảnh gốc vẫn được giữ nguyên."
        else -> "Xử lý thất bại: ${t.message ?: t.javaClass.simpleName}. Ảnh gốc vẫn được giữ nguyên."
    }

    private companion object {
        const val PREVIEW_MAX = 1536
    }
}
