package com.godly.enhancer.media

import android.content.ContentResolver
import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import java.io.File
import java.io.OutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

enum class ExportFormat(val ext: String, val mime: String, val label: String) {
    WEBP("webp", "image/webp", "WebP chất lượng 95"),
    PNG("png", "image/png", "PNG không mất dữ liệu"),
}

data class ExportResult(
    val uri: Uri,
    val name: String,
    val format: ExportFormat,
    val bytes: Long,
    val width: Int,
    val height: Int,
)

class ExportException(message: String) : Exception(message)

/**
 * Xuất ảnh bằng MediaStore: tệp mới, tên duy nhất, không ghi đè. Giữ nguyên kích thước.
 * Chỉ trả kết quả thành công sau khi mở lại tệp đã lưu và kiểm tra kích thước + dung lượng thật.
 */
object ImageExporter {
    const val WEBP_QUALITY = 95
    private const val FOLDER = "Godly Enhancer"

    fun export(context: Context, source: File, format: ExportFormat): ExportResult {
        val cr = context.contentResolver
        val srcBounds = ImageIO.fileBounds(source)
            ?: throw ExportException("Không đọc được ảnh kết quả tạm.")
        val srcDims = srcBounds.outWidth to srcBounds.outHeight
        val srcIsPng = srcBounds.outMimeType == "image/png"

        val name = uniqueName(cr, format)
        val values = ContentValues().apply {
            put(MediaStore.Images.Media.DISPLAY_NAME, name)
            put(MediaStore.Images.Media.MIME_TYPE, format.mime)
            put(MediaStore.Images.Media.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/" + FOLDER)
            put(MediaStore.Images.Media.IS_PENDING, 1)
        }
        val uri = cr.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
            ?: throw ExportException("Không tạo được tệp trong thư viện ảnh.")

        try {
            val out = cr.openOutputStream(uri, "w")
                ?: throw ExportException("Không mở được tệp đích để ghi.")
            out.use { write(source, format, srcIsPng, it) }

            cr.update(uri, ContentValues().apply { put(MediaStore.Images.Media.IS_PENDING, 0) }, null, null)

            val bytes = querySize(cr, uri)
            val outDims = readUriDims(cr, uri)
            if (bytes <= 0L || outDims == null || outDims != srcDims) {
                throw ExportException("Tệp đã lưu không hợp lệ (dung lượng hoặc kích thước không khớp).")
            }
            return ExportResult(uri, name, format, bytes, outDims.first, outDims.second)
        } catch (t: Throwable) {
            runCatching { cr.delete(uri, null, null) }
            throw if (t is ExportException) t else ExportException(
                if (t is OutOfMemoryError) "Không đủ RAM để mã hóa. Hãy thử xuất PNG."
                else "Lưu ảnh thất bại: ${t.message ?: t.javaClass.simpleName}"
            )
        }
    }

    @Suppress("DEPRECATION")
    private fun webpFormat(): Bitmap.CompressFormat =
        if (Build.VERSION.SDK_INT >= 30) Bitmap.CompressFormat.WEBP_LOSSY else Bitmap.CompressFormat.WEBP

    private fun write(source: File, format: ExportFormat, srcIsPng: Boolean, out: OutputStream) {
        when {
            format == ExportFormat.PNG && srcIsPng ->
                // Kết quả đã là PNG không mất dữ liệu → chép nguyên byte, không mã hóa lại.
                source.inputStream().use { it.copyTo(out) }
            else -> {
                val bmp = BitmapFactory.decodeFile(source.path)
                    ?: throw ExportException("Không giải mã được ảnh kết quả.")
                try {
                    val ok = if (format == ExportFormat.PNG) {
                        bmp.compress(Bitmap.CompressFormat.PNG, 100, out)
                    } else {
                        bmp.compress(webpFormat(), WEBP_QUALITY, out)
                    }
                    if (!ok) throw ExportException("Bộ mã hóa ${format.ext.uppercase(Locale.US)} thất bại.")
                } finally {
                    bmp.recycle()
                }
            }
        }
    }

    private fun uniqueName(cr: ContentResolver, format: ExportFormat): String {
        val stamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        for (n in 0..999) {
            val suffix = if (n == 0) "" else "_$n"
            val name = "Godly_Enhanced_$stamp$suffix.${format.ext}"
            if (!exists(cr, name)) return name
        }
        throw ExportException("Không tìm được tên tệp duy nhất.")
    }

    private fun exists(cr: ContentResolver, name: String): Boolean =
        cr.query(
            MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
            arrayOf(MediaStore.Images.Media._ID),
            "${MediaStore.Images.Media.DISPLAY_NAME}=? AND ${MediaStore.Images.Media.RELATIVE_PATH} LIKE ?",
            arrayOf(name, "%$FOLDER%"),
            null,
        )?.use { it.count > 0 } ?: false

    private fun querySize(cr: ContentResolver, uri: Uri): Long =
        cr.query(uri, arrayOf(MediaStore.Images.Media.SIZE), null, null, null)?.use {
            if (it.moveToFirst()) it.getLong(0) else -1L
        } ?: -1L

    private fun readUriDims(cr: ContentResolver, uri: Uri): Pair<Int, Int>? {
        val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        cr.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, o) }
        return if (o.outWidth > 0 && o.outHeight > 0) o.outWidth to o.outHeight else null
    }
}
