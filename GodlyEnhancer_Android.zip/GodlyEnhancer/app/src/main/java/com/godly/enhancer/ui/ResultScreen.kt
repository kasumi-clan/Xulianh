package com.godly.enhancer.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.godly.enhancer.UiState
import com.godly.enhancer.formatSeconds
import com.godly.enhancer.media.ExportFormat

@Composable
fun ResultScreen(
    s: UiState,
    onCompare: () -> Unit,
    onSave: (ExportFormat) -> Unit,
    onNewPhoto: () -> Unit,
    onLeave: () -> Unit,
) {
    var pendingLeave by remember { mutableStateOf<(() -> Unit)?>(null) }
    var showFormats by remember { mutableStateOf(false) }

    fun guarded(action: () -> Unit) {
        if (s.saving) return
        if (s.saved) action() else pendingLeave = action
    }

    BackHandler { guarded(onLeave) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.White)
            .systemBarsPadding()
            .verticalScroll(rememberScrollState())
            .padding(20.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Text(
            "Ảnh đã phục hồi",
            style = MaterialTheme.typography.headlineMedium,
            fontWeight = FontWeight.Bold,
            color = GodlyBlue,
        )
        Spacer(Modifier.height(14.dp))

        val bmp = s.resultPreview
        if (bmp != null) {
            val img = remember(bmp) { bmp.asImageBitmap() }
            Image(
                bitmap = img,
                contentDescription = "Ảnh đã phục hồi",
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(max = 420.dp)
                    .clip(RoundedCornerShape(16.dp)),
                contentScale = ContentScale.Fit,
            )
        }
        Spacer(Modifier.height(12.dp))

        s.sourceInfo?.let { Text("Ảnh gốc: ${it.width} × ${it.height} px", color = GodlyMuted) }
        s.result?.let {
            Text("Ảnh đầu ra: ${it.width} × ${it.height} px", color = GodlyMuted)
            Text("Thời gian xử lý (đo thực tế): ${formatSeconds(it.millis)}", color = GodlyMuted)
        }
        s.summary?.let { sm ->
            Spacer(Modifier.height(6.dp))
            if (sm.executed.isNotEmpty()) {
                Text(executedLine(sm.executed), style = MaterialTheme.typography.bodySmall, color = GodlyText)
            }
            sm.skipped.forEach {
                Text("Đã bỏ qua — $it", style = MaterialTheme.typography.bodySmall, color = GodlyMuted)
            }
        }
        Spacer(Modifier.height(16.dp))

        Button(
            onClick = onCompare,
            enabled = !s.saving,
            modifier = Modifier.fillMaxWidth().height(50.dp),
        ) { Text("↔ So sánh ảnh") }
        Spacer(Modifier.height(8.dp))
        Button(
            onClick = { showFormats = true },
            enabled = !s.saving,
            modifier = Modifier.fillMaxWidth().height(50.dp),
        ) {
            if (s.saving) {
                CircularProgressIndicator(Modifier.size(22.dp), color = Color.White, strokeWidth = 2.dp)
            } else {
                Text("💾 Lưu ảnh")
            }
        }
        Spacer(Modifier.height(8.dp))
        OutlinedButton(
            onClick = { guarded(onNewPhoto) },
            enabled = !s.saving,
            modifier = Modifier.fillMaxWidth().height(50.dp),
        ) { Text("Xử lý ảnh khác") }

        s.message?.let {
            Spacer(Modifier.height(14.dp))
            Text(it, textAlign = TextAlign.Center, color = GodlyText)
        }
    }

    if (showFormats) {
        AlertDialog(
            onDismissRequest = { showFormats = false },
            title = { Text("Chọn định dạng lưu") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(
                        onClick = { showFormats = false; onSave(ExportFormat.WEBP) },
                        modifier = Modifier.fillMaxWidth(),
                    ) { Text("Nén thông minh — WebP chất lượng 95") }
                    Text(
                        "Giữ nguyên kích thước. Dung lượng thực tế phụ thuộc nội dung ảnh.",
                        style = MaterialTheme.typography.bodySmall, color = GodlyMuted,
                    )
                    OutlinedButton(
                        onClick = { showFormats = false; onSave(ExportFormat.PNG) },
                        modifier = Modifier.fillMaxWidth(),
                    ) { Text("PNG — không mất dữ liệu") }
                    Text(
                        "Dung lượng có thể lớn hơn.",
                        style = MaterialTheme.typography.bodySmall, color = GodlyMuted,
                    )
                }
            },
            confirmButton = {},
            dismissButton = { TextButton(onClick = { showFormats = false }) { Text("Hủy") } },
        )
    }

    pendingLeave?.let { action ->
        AlertDialog(
            onDismissRequest = { pendingLeave = null },
            text = { Text("Ảnh chưa được lưu. Bạn có muốn rời khỏi không?") },
            confirmButton = { TextButton(onClick = { pendingLeave = null; action() }) { Text("Rời khỏi") } },
            dismissButton = { TextButton(onClick = { pendingLeave = null }) { Text("Ở lại") } },
        )
    }
}
