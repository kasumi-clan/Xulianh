package com.godly.enhancer.pipeline

import android.content.Context
import android.net.Uri
import android.os.SystemClock
import com.godly.enhancer.ImageInfo
import com.godly.enhancer.engine.EngineRegistry
import com.godly.enhancer.engine.EngineStatus
import com.godly.enhancer.engine.RestoreRequest
import com.godly.enhancer.engine.StageType
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import java.io.File

data class StageRun(val stage: StageType, val millis: Long)

class PipelineResult(
    val output: File?,
    val executed: List<StageRun>,
    /** Giai đoạn bị bỏ qua khi chạy (lỗi/đầu ra bị loại), kèm lý do chính xác. */
    val skipped: List<String>,
)

/**
 * Chạy các giai đoạn TUẦN TỰ (một model tại một thời điểm), giải phóng engine sau mỗi giai đoạn.
 * Giai đoạn lỗi hoặc đầu ra không hợp lệ bị bỏ qua an toàn: giữ đầu ra hợp lệ trước đó (hoặc ảnh gốc),
 * không bao giờ thay bằng model khác hay tạo đầu ra giả.
 */
class RestorePipeline(private val registry: EngineRegistry) {

    suspend fun run(
        context: Context,
        source: Uri,
        sourceInfo: ImageInfo,
        workDir: File,
        finalOutput: File,
        steps: List<PlannedStep>,
        onStage: (String?) -> Unit,
        onProgress: (Float) -> Unit,
        isThermalCritical: () -> Boolean,
    ): PipelineResult {
        val executed = mutableListOf<StageRun>()
        val skipped = mutableListOf<String>()
        var currentUri = source
        var currentFile: File? = null
        var currentDims = sourceInfo.width to sourceInfo.height

        for ((i, step) in steps.withIndex()) {
            currentCoroutineContext().ensureActive()
            val engine = registry.engine(step.stage)
            val st = engine.status
            if (st !is EngineStatus.Ready) {
                skipped += "${step.stage.label}: " + when (st) {
                    is EngineStatus.Blocked -> st.reason
                    else -> "model chưa được cài"
                }
                continue
            }
            onStage(step.stage.runningLabel)
            val out = File(workDir, "stage${i}_${step.stage.name}.png")
            val t0 = SystemClock.elapsedRealtime()
            try {
                engine.restore(RestoreRequest(context, currentUri, workDir, out, onProgress, isThermalCritical))
                val v = StageValidator.validate(context, step.stage, currentDims, currentUri, out)
                if (!v.ok) {
                    out.delete()
                    skipped += "${step.stage.label}: đầu ra bị loại — ${v.reason}"
                    continue
                }
                executed += StageRun(step.stage, SystemClock.elapsedRealtime() - t0)
                currentFile?.delete() // xóa trung gian cũ (không phải ảnh gốc)
                currentFile = out
                currentUri = Uri.fromFile(out)
                currentDims = v.dims ?: currentDims
            } catch (e: CancellationException) {
                out.delete()
                throw e
            } catch (t: Throwable) {
                out.delete()
                skipped += "${step.stage.label}: " + if (t is OutOfMemoryError) {
                    "không đủ RAM"
                } else {
                    t.message ?: t.javaClass.simpleName
                }
            } finally {
                engine.release()
            }
        }

        onStage("Đang hoàn thiện ảnh")
        val last = currentFile ?: return PipelineResult(null, executed, skipped)
        if (!last.renameTo(finalOutput)) {
            last.copyTo(finalOutput, overwrite = true)
            last.delete()
        }
        return PipelineResult(finalOutput, executed, skipped)
    }
}
