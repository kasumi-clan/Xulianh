package com.godly.enhancer.engine

import java.io.File

/**
 * Khung engine CHƯA có suy luận thật. Cố ý không giả lập kết quả và không thay bằng model khác.
 * Khi một model được chuyển đổi + kiểm chứng trên Android, thay lớp tương ứng bằng bản chạy thật.
 */
abstract class UnavailableEngine(private val reason: String) : RestorationEngine {
    override val status: EngineStatus get() = EngineStatus.Blocked(reason)
    override fun estimateRamBytes(width: Int, height: Int): Long? = null
    override suspend fun restore(request: RestoreRequest) {
        throw IllegalStateException(reason)
    }
    override fun release() = Unit
}

private const val VOSR_BLOCK =
    "VOSR 0.5B One-Step (DiT 0.5B + VAE SD2.1 decoder nhẹ + DINOv2) chỉ có bản PyTorch; " +
        "chưa chuyển sang runtime Android, chưa chạy suy luận trên Android."
private const val NAF_DENOISE_BLOCK =
    "Checkpoint NAFNet SIDD chỉ phát hành dạng PyTorch (.pth); chưa chuyển sang runtime Android, chưa chạy suy luận."
private const val NAF_DEBLUR_BLOCK =
    "Checkpoint NAFNet GoPro chỉ phát hành dạng PyTorch (.pth); chưa chuyển sang runtime Android, chưa chạy suy luận."
private const val CODEFORMER_BLOCK =
    "CodeFormer cần thêm bước dò/căn chỉnh khuôn mặt và ghép lại; chưa có bản Android, chưa kiểm thử. " +
        "Giấy phép S-Lab 1.0 cần được rà soát trước khi phát hành."

class VosrEngine : UnavailableEngine(VOSR_BLOCK)
class NafnetDenoiseEngine : UnavailableEngine(NAF_DENOISE_BLOCK)
class NafnetDeblurEngine : UnavailableEngine(NAF_DEBLUR_BLOCK)
class CodeFormerEngine : UnavailableEngine(CODEFORMER_BLOCK)

/** Sổ đăng ký engine + vùng lưu trọng số (filesDir/models/<stage>) — không bị "Dọn bộ nhớ tạm" đụng tới. */
class EngineRegistry(modelsRoot: File) {
    private val engines: Map<StageType, RestorationEngine> = mapOf(
        StageType.NafnetDenoise to NafnetDenoiseEngine(),
        StageType.NafnetDeblur to NafnetDeblurEngine(),
        StageType.Vosr to VosrEngine(),
        StageType.CodeFormer to CodeFormerEngine(),
    )
    private val stores: Map<StageType, ModelStore> =
        StageType.values().associateWith { ModelStore(File(modelsRoot, it.name)) }

    fun engine(stage: StageType): RestorationEngine = engines.getValue(stage)

    fun statuses(): Map<StageType, EngineStatus> =
        StageType.values().associateWith { engines.getValue(it).status }

    fun availability(width: Int, height: Int): Map<StageType, com.godly.enhancer.pipeline.StageAvailability> =
        StageType.values().associateWith {
            val e = engines.getValue(it)
            com.godly.enhancer.pipeline.StageAvailability(e.status, e.estimateRamBytes(width, height))
        }

    fun installedBytes(): Long = stores.values.sumOf { it.installedBytes() }

    fun deleteAllModels(): Boolean = stores.values.map { it.delete() }.all { it }

    fun releaseAll() = engines.values.forEach { it.release() }
}
