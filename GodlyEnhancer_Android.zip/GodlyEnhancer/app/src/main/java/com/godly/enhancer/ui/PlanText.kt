package com.godly.enhancer.ui

import com.godly.enhancer.analysis.AnalysisReport
import com.godly.enhancer.engine.EngineStatus
import com.godly.enhancer.formatBytes
import com.godly.enhancer.formatSeconds
import com.godly.enhancer.pipeline.RestorePlan
import com.godly.enhancer.pipeline.StageRun
import java.util.Locale

fun engineText(e: EngineStatus): String = when (e) {
    is EngineStatus.Ready -> "Sẵn sàng (${e.modelName} · ${e.backend})"
    EngineStatus.NotInstalled -> "Model chưa được cài"
    is EngineStatus.Blocked -> "Chưa dùng được: ${e.reason}"
}

private fun f1(x: Double) = String.format(Locale.US, "%.1f", x)

/** Số đo chỉ là ước lượng — nói rõ để không gây hiểu lầm. */
fun analysisLines(a: AnalysisReport): List<String> = buildList {
    add("Độ phân giải: ${a.width} × ${a.height} px")
    add(if (a.noiseSigma != null) "Nhiễu ước lượng: σ≈${f1(a.noiseSigma)} (thang 0–255)" else "Nhiễu: không đo được")
    add(
        if (a.sharpness != null) {
            "Độ nét ước lượng: ${f1(a.sharpness)}" + (a.anisotropy?.let { " · bất đẳng hướng ${f1(it)}" } ?: "")
        } else "Độ nét: không đo được"
    )
    add("Khuôn mặt phát hiện: ${a.faces.size} (${a.faceNote})")
    add("RAM trống: ${formatBytes(a.availMemBytes)}")
}

fun planLines(p: RestorePlan): List<String> = buildList {
    if (p.steps.isEmpty()) {
        add("Kế hoạch: không cần dùng model AI.")
    } else {
        add("Kế hoạch (tuần tự): " + p.steps.joinToString(" → ") { it.stage.label })
        p.steps.forEach { add("• ${it.stage.label}: ${it.reason}") }
    }
    p.blocked.forEach { add("Không chạy được — ${it.stage.label}: ${it.reason}") }
    p.notes.forEach { add(it) }
}

fun executedLine(runs: List<StageRun>): String =
    "Đã chạy: " + runs.joinToString(" → ") { "${it.stage.label} (${formatSeconds(it.millis)})" }
