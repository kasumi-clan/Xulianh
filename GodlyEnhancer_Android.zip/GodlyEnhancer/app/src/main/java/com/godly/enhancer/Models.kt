package com.godly.enhancer

import android.graphics.Bitmap
import android.net.Uri
import com.godly.enhancer.analysis.AnalysisReport
import com.godly.enhancer.engine.EngineStatus
import com.godly.enhancer.engine.StageType
import com.godly.enhancer.pipeline.RestorePlan
import com.godly.enhancer.pipeline.StageRun
import java.io.File

enum class Screen { Home, Result, Compare, Settings }

data class ImageInfo(val width: Int, val height: Int, val mime: String?)

data class ResultInfo(val file: File, val width: Int, val height: Int, val millis: Long)

data class RunSummary(val executed: List<StageRun>, val skipped: List<String>)

data class StorageStats(
    val modelBytes: Long = 0L,
    val tempBytes: Long = 0L,
    val sessionBytes: Long = 0L,
)

data class UiState(
    val models: Map<StageType, EngineStatus>,
    val screen: Screen = Screen.Home,
    val sourceUri: Uri? = null,
    val sourceInfo: ImageInfo? = null,
    val sourcePreview: Bitmap? = null,
    val faceOptIn: Boolean = false,
    /** Đang phân tích hoặc đang chạy pipeline. */
    val processing: Boolean = false,
    /** Chỉ là giai đoạn ĐANG chạy thật. */
    val stageLabel: String? = null,
    val progress: Float? = null,
    val analysis: AnalysisReport? = null,
    val plan: RestorePlan? = null,
    val summary: RunSummary? = null,
    val result: ResultInfo? = null,
    val resultPreview: Bitmap? = null,
    val saved: Boolean = false,
    val saving: Boolean = false,
    val message: String? = null,
    val storage: StorageStats = StorageStats(),
    val thermal: Int = 0,
)
