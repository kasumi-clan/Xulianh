package com.godly.enhancer.analysis

import android.app.ActivityManager
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.BitmapRegionDecoder
import android.graphics.PointF
import android.graphics.Rect
import android.media.FaceDetector
import android.net.Uri
import android.os.Build
import com.godly.enhancer.ImageInfo
import com.godly.enhancer.media.ImageIO
import java.io.InputStream
import kotlin.math.min

/**
 * Phân tích ảnh TRƯỚC khi suy luận: đo nhiễu/độ nét trên vài vùng cắt ở độ phân giải gốc,
 * dò khuôn mặt cơ bản, đọc RAM khả dụng. Mọi kết quả chỉ là ước lượng.
 */
class ImageAnalyzer(private val context: Context) {

    fun analyze(uri: Uri, info: ImageInfo, preview: Bitmap): AnalysisReport {
        val crops = sampleCrops(uri)
        val noises = crops.map { ImageMetrics.noiseSigma(it) }.sorted()
        val noise = if (noises.isEmpty()) null else noises[noises.size / 2]
        val half = crops.map { ImageMetrics.downsample2(it) }
        val sharpness = half.maxOfOrNull { ImageMetrics.laplacianVariance(it) }
        val anisos = half.map { ImageMetrics.anisotropy(it) }.sorted()
        val aniso = if (anisos.isEmpty()) null else anisos[anisos.size / 2]
        val (faces, faceNote) = detectFaces(preview, info)

        val mi = ActivityManager.MemoryInfo()
        context.getSystemService(ActivityManager::class.java).getMemoryInfo(mi)

        return AnalysisReport(
            width = info.width, height = info.height,
            noiseSigma = noise, sharpness = sharpness, anisotropy = aniso,
            cropsUsed = crops.size, faces = faces, faceNote = faceNote,
            availMemBytes = mi.availMem, lowMemory = mi.lowMemory,
        )
    }

    /** Lấy tối đa 5 vùng CROP×CROP ở độ phân giải gốc (giữa + 4 góc phần tư). */
    private fun sampleCrops(uri: Uri): List<Gray> {
        val stream: InputStream? = try {
            context.contentResolver.openInputStream(uri)
        } catch (e: Exception) {
            null
        }
        if (stream == null) return emptyList()
        val out = ArrayList<Gray>()
        try {
            val decoder = newRegionDecoder(stream)
            if (decoder == null) return emptyList()
            try {
                val w = decoder.width
                val h = decoder.height
                val size = min(CROP, min(w, h))
                if (size < 16) return emptyList()
                val fx = floatArrayOf(0.5f, 0.25f, 0.75f, 0.25f, 0.75f)
                val fy = floatArrayOf(0.5f, 0.25f, 0.25f, 0.75f, 0.75f)
                for (i in fx.indices) {
                    val l = ((w * fx[i]).toInt() - size / 2).coerceIn(0, w - size)
                    val t = ((h * fy[i]).toInt() - size / 2).coerceIn(0, h - size)
                    val opts = BitmapFactory.Options().apply { inPreferredConfig = Bitmap.Config.ARGB_8888 }
                    val bmp = decoder.decodeRegion(Rect(l, t, l + size, t + size), opts)
                    if (bmp == null) continue
                    out += ImageIO.toGray(bmp)
                    bmp.recycle()
                }
            } finally {
                decoder.recycle()
            }
        } catch (e: Exception) {
            return emptyList()
        } catch (e: OutOfMemoryError) {
            return emptyList()
        } finally {
            runCatching { stream.close() }
        }
        return out
    }

    @Suppress("DEPRECATION")
    private fun newRegionDecoder(stream: InputStream): BitmapRegionDecoder? =
        if (Build.VERSION.SDK_INT >= 31) {
            BitmapRegionDecoder.newInstance(stream)
        } else {
            BitmapRegionDecoder.newInstance(stream, false)
        }

    private fun detectFaces(preview: Bitmap, info: ImageInfo): Pair<List<FaceInfo>, String> {
        val note = "dò mặt cơ bản của Android: chỉ mặt gần chính diện, có thể bỏ sót hoặc nhầm"
        try {
            val rgb = preview.copy(Bitmap.Config.RGB_565, false) ?: return emptyList<FaceInfo>() to note
            val evenW = rgb.width and 1.inv()
            val bmp = if (evenW == rgb.width) rgb else Bitmap.createBitmap(rgb, 0, 0, evenW, rgb.height)
            val detector = FaceDetector(bmp.width, bmp.height, MAX_FACES)
            val found = arrayOfNulls<FaceDetector.Face>(MAX_FACES)
            val n = detector.findFaces(bmp, found)
            val scale = info.width.toFloat() / preview.width.toFloat()
            val out = ArrayList<FaceInfo>()
            for (i in 0 until n) {
                val f = found[i] ?: continue
                if (f.confidence() < FaceDetector.Face.CONFIDENCE_THRESHOLD) continue
                val mid = PointF()
                f.getMidPoint(mid)
                val eye = f.eyesDistance()
                val half = (eye * 1.6f).toInt().coerceAtLeast(8)
                val l = (mid.x.toInt() - half).coerceIn(0, preview.width - 1)
                val t = (mid.y.toInt() - half).coerceIn(0, preview.height - 1)
                val rw = min(half * 2, preview.width - l)
                val rh = min(half * 2, preview.height - t)
                val sharp = if (rw >= 16 && rh >= 16) {
                    ImageMetrics.laplacianVariance(ImageIO.toGray(Bitmap.createBitmap(preview, l, t, rw, rh)))
                } else null
                val eyeNative = eye * scale
                val degraded = eyeNative < Thresholds.FACE_SMALL_EYE_DIST_PX ||
                    (sharp != null && sharp < Thresholds.FACE_SHARPNESS_LOW)
                out += FaceInfo(eyeNative, sharp, degraded)
            }
            return out to note
        } catch (e: Exception) {
            return emptyList<FaceInfo>() to "$note (lỗi khi dò: ${e.message})"
        }
    }

    private companion object {
        const val CROP = 384
        const val MAX_FACES = 5
    }
}
