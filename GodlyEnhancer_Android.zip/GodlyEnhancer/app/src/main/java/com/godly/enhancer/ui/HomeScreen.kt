package com.godly.enhancer.ui

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.godly.enhancer.UiState
import com.godly.enhancer.engine.EngineStatus
import com.godly.enhancer.engine.StageType
import com.godly.enhancer.thermalLabel
import kotlin.math.roundToInt

@Composable
fun HomeScreen(
    s: UiState,
    onPick: () -> Unit,
    onRestore: () -> Unit,
    onCancel: () -> Unit,
    onSettings: () -> Unit,
    onFaceOptIn: (Boolean) -> Unit,
) {
    val anyReady = s.models.values.any { it is EngineStatus.Ready }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.White)
            .systemBarsPadding()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp, vertical = 12.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
            TextButton(onClick = onSettings, enabled = !s.processing) { Text("⚙ Cài đặt") }
        }
        Text(
            "Godly Enhancer",
            style = MaterialTheme.typography.headlineLarge,
            fontWeight = FontWeight.Bold,
            color = GodlyBlue,
        )
        Text("Làm đẹp và phục hồi ảnh", style = MaterialTheme.typography.bodyLarge, color = GodlyMuted)
        Spacer(Modifier.height(20.dp))

        Card(
            onClick = onPick,
            enabled = !s.processing,
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = GodlyBlueSoft),
        ) {
            Column(
                Modifier.fillMaxWidth().padding(16.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                val bmp = s.sourcePreview
                if (bmp != null) {
                    val img = remember(bmp) { bmp.asImageBitmap() }
                    Image(
                        bitmap = img,
                        contentDescription = "Ảnh xem trước",
                        modifier = Modifier
                            .fillMaxWidth()
                            .heightIn(max = 380.dp)
                            .clip(RoundedCornerShape(14.dp)),
                        contentScale = ContentScale.Fit,
                    )
                } else {
                    Text("🖼", style = MaterialTheme.typography.displayMedium)
                }
                Spacer(Modifier.height(10.dp))
                Text("Chọn một bức ảnh", fontWeight = FontWeight.SemiBold, color = GodlyBlue)
                s.sourceInfo?.let {
                    Text("Ảnh gốc: ${it.width} × ${it.height} px", style = MaterialTheme.typography.bodyMedium, color = GodlyMuted)
                }
            }
        }

        Spacer(Modifier.height(12.dp))
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("Cải thiện khuôn mặt (tùy chọn)", fontWeight = FontWeight.SemiBold, color = GodlyText)
                Text(
                    "Dùng CodeFormer khi phát hiện khuôn mặt chưa rõ. Không hứa giữ nguyên danh tính tuyệt đối.",
                    style = MaterialTheme.typography.bodySmall, color = GodlyMuted,
                )
            }
            Switch(checked = s.faceOptIn, onCheckedChange = onFaceOptIn, enabled = !s.processing)
        }

        Spacer(Modifier.height(16.dp))
        if (s.processing) {
            val p = s.progress
            if (p == null) {
                LinearProgressIndicator(Modifier.fillMaxWidth())
            } else {
                LinearProgressIndicator(progress = { p }, modifier = Modifier.fillMaxWidth())
            }
            Spacer(Modifier.height(8.dp))
            Text(
                (s.stageLabel ?: "Đang xử lý") + if (p == null) "…" else "… ${(p * 100).roundToInt()}%",
                color = GodlyText,
            )
            Spacer(Modifier.height(8.dp))
            OutlinedButton(onClick = onCancel) { Text("Hủy") }
        } else {
            Button(
                onClick = onRestore,
                enabled = s.sourceUri != null,
                modifier = Modifier.fillMaxWidth().height(52.dp),
            ) { Text("✨ Làm rõ ảnh", fontWeight = FontWeight.SemiBold) }
        }

        s.message?.let {
            Spacer(Modifier.height(12.dp))
            Text(it, style = MaterialTheme.typography.bodyMedium, color = GodlyText, textAlign = TextAlign.Center)
        }
        thermalLabel(s.thermal)?.let {
            Spacer(Modifier.height(6.dp))
            Text(it, style = MaterialTheme.typography.bodyMedium, color = GodlyMuted, textAlign = TextAlign.Center)
        }

        val analysis = s.analysis
        val plan = s.plan
        if (analysis != null) {
            Spacer(Modifier.height(14.dp))
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = GodlyBlueSoft),
            ) {
                Column(Modifier.padding(14.dp)) {
                    Text("Phân tích ảnh (chỉ là ước lượng)", fontWeight = FontWeight.SemiBold, color = GodlyBlue)
                    Spacer(Modifier.height(4.dp))
                    analysisLines(analysis).forEach { Text("• $it", style = MaterialTheme.typography.bodySmall, color = GodlyText) }
                    if (plan != null) {
                        Spacer(Modifier.height(8.dp))
                        planLines(plan).forEach { Text(it, style = MaterialTheme.typography.bodySmall, color = GodlyText) }
                    }
                }
            }
        }

        Spacer(Modifier.height(16.dp))
        Text("Model AI", fontWeight = FontWeight.SemiBold, color = GodlyText)
        StageType.values().forEach { st ->
            val ready = s.models[st] is EngineStatus.Ready
            Text(
                "• ${st.label}: " + if (ready) "sẵn sàng" else "chưa dùng được (xem Cài đặt)",
                style = MaterialTheme.typography.bodySmall,
                color = if (ready) GodlyBlue else GodlyMuted,
            )
        }

        Spacer(Modifier.height(12.dp))
        // Chỉ khẳng định "xử lý trên thiết bị" khi có model thật sự sẵn sàng.
        Text(
            if (anyReady) "AI được tải một lần. Sau khi cài đặt, ảnh được xử lý trực tiếp trên thiết bị."
            else "Ứng dụng không tải ảnh của bạn lên mạng.",
            style = MaterialTheme.typography.bodySmall,
            color = GodlyMuted,
            textAlign = TextAlign.Center,
        )
    }
}
