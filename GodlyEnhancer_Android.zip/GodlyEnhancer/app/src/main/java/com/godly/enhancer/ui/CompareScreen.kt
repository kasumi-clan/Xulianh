package com.godly.enhancer.ui

import android.graphics.Bitmap
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.FilterQuality
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.clipRect
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import kotlin.math.roundToInt

private fun fitRect(box: Size, aspect: Float): Rect {
    if (box.width <= 0f || box.height <= 0f || aspect <= 0f) return Rect(0f, 0f, 0f, 0f)
    var w = box.width
    var h = w / aspect
    if (h > box.height) {
        h = box.height
        w = h * aspect
    }
    val l = (box.width - w) / 2f
    val t = (box.height - h) / 2f
    return Rect(l, t, l + w, t + h)
}

/**
 * So sánh Trước/Sau: hai ảnh dùng chung một khung (cùng tỷ lệ, không kéo giãn),
 * đường chia dọc kéo được. Dùng bản xem trước thu nhỏ — không nạp thêm ảnh độ phân giải đầy đủ,
 * không chạy lại AI, không tạo tệp mới. Zoom: chưa triển khai.
 */
@Composable
fun CompareScreen(before: Bitmap, after: Bitmap, onBack: () -> Unit) {
    BackHandler(onBack = onBack)

    var frac by remember { mutableFloatStateOf(0.5f) }
    var box by remember { mutableStateOf(IntSize.Zero) }
    val beforeImg = remember(before) { before.asImageBitmap() }
    val afterImg = remember(after) { after.asImageBitmap() }
    val aspect = before.width.toFloat() / before.height.toFloat()

    Column(
        Modifier
            .fillMaxSize()
            .background(Color.White)
            .systemBarsPadding(),
    ) {
        Row(
            Modifier.fillMaxWidth().padding(8.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            TextButton(onClick = onBack) { Text("← Quay lại") }
            Spacer(Modifier.weight(1f))
            OutlinedButton(onClick = { frac = 0.5f }) { Text("Đặt lại") }
        }

        Box(Modifier.weight(1f).fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp)) {
            Canvas(
                Modifier
                    .fillMaxSize()
                    .onSizeChanged { box = it }
                    .pointerInput(box, aspect) {
                        val r = fitRect(Size(box.width.toFloat(), box.height.toFloat()), aspect)
                        detectHorizontalDragGestures { change, _ ->
                            change.consume()
                            if (r.width > 0f) {
                                frac = ((change.position.x - r.left) / r.width).coerceIn(0f, 1f)
                            }
                        }
                    },
            ) {
                val r = fitRect(size, aspect)
                val off = IntOffset(r.left.roundToInt(), r.top.roundToInt())
                val dst = IntSize(r.width.roundToInt(), r.height.roundToInt())
                drawImage(beforeImg, dstOffset = off, dstSize = dst, filterQuality = FilterQuality.Medium)

                val x = r.left + r.width * frac
                clipRect(left = x, top = r.top, right = r.right, bottom = r.bottom) {
                    drawImage(afterImg, dstOffset = off, dstSize = dst, filterQuality = FilterQuality.Medium)
                }
                drawLine(Color.White, Offset(x, r.top), Offset(x, r.bottom), strokeWidth = 3.dp.toPx())
                drawCircle(Color.White, radius = 16.dp.toPx(), center = Offset(x, r.center.y))
                drawCircle(GodlyBlue, radius = 12.dp.toPx(), center = Offset(x, r.center.y))
            }
            Text(
                "Trước",
                color = Color.White,
                modifier = Modifier
                    .align(Alignment.TopStart)
                    .background(Color(0x99000000), RoundedCornerShape(8.dp))
                    .padding(horizontal = 10.dp, vertical = 4.dp),
            )
            Text(
                "Sau",
                color = Color.White,
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .background(Color(0x99000000), RoundedCornerShape(8.dp))
                    .padding(horizontal = 10.dp, vertical = 4.dp),
            )
        }
    }
}
