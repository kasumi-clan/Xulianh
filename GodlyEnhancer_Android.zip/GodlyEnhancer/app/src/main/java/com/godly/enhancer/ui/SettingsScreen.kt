package com.godly.enhancer.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.godly.enhancer.UiState
import com.godly.enhancer.engine.StageType
import com.godly.enhancer.formatBytes

@Composable
fun SettingsScreen(
    s: UiState,
    onBack: () -> Unit,
    onCleanTemp: () -> Unit,
    onDeleteModels: () -> Unit,
) {
    BackHandler(onBack = onBack)
    var confirmDelete by remember { mutableStateOf(false) }

    Column(
        Modifier
            .fillMaxSize()
            .background(Color.White)
            .systemBarsPadding()
            .verticalScroll(rememberScrollState())
            .padding(20.dp),
    ) {
        Row { TextButton(onClick = onBack) { Text("← Quay lại") } }
        Text("Cài đặt & bộ nhớ", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold, color = GodlyBlue)
        Spacer(Modifier.height(16.dp))

        Text("Bộ nhớ (số đo thật từ thiết bị)", fontWeight = FontWeight.SemiBold)
        Spacer(Modifier.height(6.dp))
        Text("Model đã tải: ${formatBytes(s.storage.modelBytes)}", color = GodlyMuted)
        Text("Tệp xử lý tạm (do ứng dụng quản lý): ${formatBytes(s.storage.tempBytes)}", color = GodlyMuted)
        Text("Phiên xử lý hiện tại: ${formatBytes(s.storage.sessionBytes)}", color = GodlyMuted)
        Spacer(Modifier.height(10.dp))
        OutlinedButton(onClick = onCleanTemp, enabled = !s.processing && !s.saving, modifier = Modifier.fillMaxWidth()) {
            Text("Dọn bộ nhớ tạm")
        }
        Text(
            "Chỉ xóa tệp tạm do ứng dụng quản lý và không đang dùng. Ảnh gốc, ảnh đã lưu và model không bị xóa.",
            style = MaterialTheme.typography.bodySmall, color = GodlyMuted,
        )

        Spacer(Modifier.height(24.dp))
        Text("Model AI (chạy tuần tự, không nạp cùng lúc)", fontWeight = FontWeight.SemiBold)
        Spacer(Modifier.height(6.dp))
        StageType.values().forEach { st ->
            val status = s.models[st]
            Text(st.label, fontWeight = FontWeight.Medium, color = GodlyText)
            Text(
                if (status != null) engineText(status) else "Không rõ",
                style = MaterialTheme.typography.bodySmall, color = GodlyMuted,
            )
            Spacer(Modifier.height(8.dp))
        }
        Text(
            "Chưa có nguồn tải model Android đã xác minh, nên chưa có nút tải.",
            style = MaterialTheme.typography.bodySmall, color = GodlyMuted,
        )
        if (s.storage.modelBytes > 0L) {
            Spacer(Modifier.height(8.dp))
            OutlinedButton(onClick = { confirmDelete = true }, enabled = !s.processing, modifier = Modifier.fillMaxWidth()) {
                Text("Xóa model đã tải")
            }
        }

        s.message?.let {
            Spacer(Modifier.height(16.dp))
            Text(it, color = GodlyText)
        }
    }

    if (confirmDelete) {
        AlertDialog(
            onDismissRequest = { confirmDelete = false },
            text = { Text("Xóa toàn bộ model đã tải? Bạn sẽ cần tải lại để xử lý ảnh.") },
            confirmButton = { TextButton(onClick = { confirmDelete = false; onDeleteModels() }) { Text("Xóa") } },
            dismissButton = { TextButton(onClick = { confirmDelete = false }) { Text("Hủy") } },
        )
    }
}
