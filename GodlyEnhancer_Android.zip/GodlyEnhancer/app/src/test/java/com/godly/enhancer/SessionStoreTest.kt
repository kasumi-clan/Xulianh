package com.godly.enhancer

import com.godly.enhancer.storage.SessionStore
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Rule
import org.junit.Test
import org.junit.rules.TemporaryFolder
import java.io.File

class SessionStoreTest {
    @get:Rule
    val tmp = TemporaryFolder()

    private lateinit var root: File
    private lateinit var store: SessionStore

    @Before
    fun setUp() {
        root = File(tmp.root, "godly_session")
        store = SessionStore(root)
    }

    @Test
    fun clearCurrentDeletesRealFilesFromDisk() {
        val dir = store.begin()
        val f = File(dir, "result.png")
        f.writeBytes(ByteArray(1024))
        assertTrue(f.exists())
        assertTrue(store.clearCurrent())
        assertFalse(f.exists())
        assertFalse(dir.exists())
    }

    @Test
    fun neverDeletesFilesOutsideRoot() {
        val original = tmp.newFile("original.jpg")
        original.writeBytes(ByteArray(10))
        assertFalse(store.delete(original))
        assertTrue(original.exists())
    }

    @Test
    fun rejectsPathTraversal() {
        val original = tmp.newFile("original2.jpg")
        original.writeBytes(ByteArray(10))
        val sneaky = File(root, "../original2.jpg")
        assertFalse(store.delete(sneaky))
        assertTrue(original.exists())
    }

    @Test
    fun cleanTempKeepsCurrentWhenInUse() {
        val inUse = store.begin()
        File(inUse, "a.bin").writeBytes(ByteArray(5))
        val stale = File(root, "s_stale")
        stale.mkdirs()
        File(stale, "b.bin").writeBytes(ByteArray(5))

        val removed = store.cleanTemp(keepCurrent = true)

        assertEquals(1, removed)
        assertTrue(inUse.exists())
        assertFalse(stale.exists())
    }

    @Test
    fun cleanTempRemovesEverythingWhenNotInUse() {
        val dir = store.begin()
        File(dir, "a.bin").writeBytes(ByteArray(5))
        store.cleanTemp(keepCurrent = false)
        assertFalse(dir.exists())
        assertEquals(0L, store.totalBytes())
    }

    @Test
    fun reportsRealByteSizes() {
        val dir = store.begin()
        File(dir, "x.bin").writeBytes(ByteArray(4096))
        assertEquals(4096L, store.totalBytes())
        assertEquals(4096L, store.currentBytes())
    }

    @Test
    fun beginDeletesPreviousSession() {
        val first = store.begin()
        File(first, "old.png").writeBytes(ByteArray(8))
        val second = store.begin()
        assertFalse(first.exists())
        assertTrue(second.exists())
    }
}
