package com.godly.enhancer

import com.godly.enhancer.analysis.AnalysisReport
import com.godly.enhancer.analysis.FaceInfo
import com.godly.enhancer.engine.EngineStatus
import com.godly.enhancer.engine.StageType
import com.godly.enhancer.pipeline.Planner
import com.godly.enhancer.pipeline.StageAvailability
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class PlannerTest {
    private val ready = EngineStatus.Ready("test", "cpu")

    private fun avail(status: EngineStatus = ready, ram: Long? = null) =
        StageType.values().associateWith { StageAvailability(status, ram) }

    private fun report(
        w: Int = 4000, h: Int = 3000, noise: Double? = 2.0, sharp: Double? = 400.0, aniso: Double? = 1.1,
        faces: List<FaceInfo> = emptyList(), mem: Long = 4_000_000_000L,
    ) = AnalysisReport(w, h, noise, sharp, aniso, 5, faces, "test", mem, false)

    private val badFace = FaceInfo(20f, 10.0, true)
    private fun stages(r: AnalysisReport, a: Map<StageType, StageAvailability> = avail(), face: Boolean = false) =
        Planner.plan(r, a, face).steps.map { it.stage }

    @Test fun clearImageSkipsEveryModel() = assertTrue(stages(report()).isEmpty())

    @Test fun highNoiseSelectsOnlyDenoise() =
        assertEquals(listOf(StageType.NafnetDenoise), stages(report(noise = 15.0)))

    @Test fun lowResolutionSelectsVosr() =
        assertEquals(listOf(StageType.Vosr), stages(report(w = 640, h = 480)))

    @Test fun motionBlurSelectsDeblur() =
        assertEquals(listOf(StageType.NafnetDeblur), stages(report(sharp = 20.0, aniso = 5.0)))

    @Test fun blurWithoutDirectionSelectsVosrNotNafnet() =
        assertEquals(listOf(StageType.Vosr), stages(report(sharp = 20.0, aniso = 1.1)))

    @Test fun flatImageNeverTriggersMotionDeblur() =
        assertFalse(stages(report(sharp = 1.0, aniso = 2.5)).contains(StageType.NafnetDeblur))

    @Test fun neverTwoNafnetOperations() {
        val s = stages(report(noise = 15.0, sharp = 5.0, aniso = 9.0))
        assertEquals(1, s.count { it == StageType.NafnetDenoise || it == StageType.NafnetDeblur })
    }

    @Test fun faceNeedsOptIn() {
        val r = report(faces = listOf(badFace))
        assertFalse(stages(r, face = false).contains(StageType.CodeFormer))
        assertTrue(Planner.plan(r, avail(), false).faceSuggested)
        assertTrue(stages(r, face = true).contains(StageType.CodeFormer))
    }

    @Test fun orderIsNafnetThenVosrThenCodeFormer() =
        assertEquals(
            listOf(StageType.NafnetDenoise, StageType.Vosr, StageType.CodeFormer),
            stages(report(w = 640, h = 480, noise = 15.0, faces = listOf(badFace)), face = true),
        )

    @Test fun blockedModelIsReportedWithExactReasonAndNotRunnable() {
        val p = Planner.plan(report(noise = 15.0), avail(EngineStatus.Blocked("lý do X")), false)
        assertTrue(p.runnable.isEmpty())
        assertEquals("lý do X", p.blocked.single().reason)
    }

    @Test fun insufficientRamBlocksStep() {
        val p = Planner.plan(report(noise = 15.0, mem = 1_000L), avail(ram = 2_000L), false)
        assertTrue(p.runnable.isEmpty())
        assertEquals(1, p.blocked.size)
    }

    @Test fun unmeasurableImageDoesNotInventDegradation() {
        val p = Planner.plan(report(noise = null, sharp = null, aniso = null), avail(), false)
        assertTrue(p.steps.isEmpty())
        assertTrue(p.notes.any { it.contains("Không đo được") })
    }
}
