package com.godly.enhancer

import com.godly.enhancer.analysis.Gray
import com.godly.enhancer.analysis.ImageMetrics
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import java.util.Random

class ImageMetricsTest {
    private fun gray(w: Int, h: Int, f: (Int, Int) -> Float) =
        Gray(w, h, FloatArray(w * h) { f(it % w, it / w) })

    private fun boxBlur5(g: Gray): Gray {
        fun pass(src: Gray, horizontal: Boolean): Gray {
            val out = FloatArray(src.w * src.h)
            for (y in 0 until src.h) {
                for (x in 0 until src.w) {
                    var sum = 0f
                    for (k in -2..2) {
                        val xx = if (horizontal) (x + k).coerceIn(0, src.w - 1) else x
                        val yy = if (horizontal) y else (y + k).coerceIn(0, src.h - 1)
                        sum += src[xx, yy]
                    }
                    out[y * src.w + x] = sum / 5f
                }
            }
            return Gray(src.w, src.h, out)
        }
        return pass(pass(g, true), false)
    }

    @Test
    fun constantImageHasZeroNoiseAndZeroLaplacian() {
        val g = gray(64, 64) { _, _ -> 128f }
        assertEquals(0.0, ImageMetrics.noiseSigma(g), 1e-9)
        assertEquals(0.0, ImageMetrics.laplacianVariance(g), 1e-9)
    }

    @Test
    fun noiseSigmaMatchesInjectedGaussianNoise() {
        val rnd = Random(42)
        val g = gray(256, 256) { _, _ -> 128f + 10f * rnd.nextGaussian().toFloat() }
        val s = ImageMetrics.noiseSigma(g)
        assertTrue("σ ước lượng=$s", s in 8.5..11.5)
    }

    @Test
    fun horizontalStripesAreStronglyAnisotropicAndNoiseIsNot() {
        val stripes = gray(64, 64) { _, y -> if ((y / 4) % 2 == 0) 0f else 100f }
        assertTrue(ImageMetrics.anisotropy(stripes) > 5.0)
        // Nhiễu trắng thuần có bất đẳng hướng ≈2.0 theo công thức này (đã đo bằng bản Python), nên dùng nhiễu đã làm mịn.
        val rnd = Random(7)
        val noise = boxBlur5(gray(128, 128) { _, _ -> 128f + 20f * rnd.nextGaussian().toFloat() })
        assertTrue(ImageMetrics.anisotropy(noise) < 1.5)
    }

    @Test
    fun downsampleHalvesSizeAndAverages() {
        val g = gray(4, 4) { x, _ -> if (x < 2) 0f else 100f }
        val d = ImageMetrics.downsample2(g)
        assertEquals(2, d.w); assertEquals(2, d.h)
        assertEquals(0f, d[0, 0], 1e-6f); assertEquals(100f, d[1, 0], 1e-6f)
    }

    @Test
    fun lumaStatsOfConstantImage() {
        val s = ImageMetrics.lumaStats(gray(16, 16) { _, _ -> 100f })
        assertEquals(100f, s.p1, 0f); assertEquals(100f, s.p99, 0f); assertEquals(100f, s.mean, 1e-4f)
    }
}
